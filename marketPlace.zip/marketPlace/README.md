# MARKET PLACE

#### Video Demo: [Youtube](https://www.youtube.com/watch?v=H6NvzEwfhdo)

#### Description:

Welcome to the Market Place, a web store application that provides a platform for users to publish items for sale. This application is designed with the user in mind, providing a seamless and intuitive user experience.

## Technologies Used

This application is built with the following technologies:

- **Django Framework**: Django is a high-level Python Web framework that encourages rapid development and clean, pragmatic design. Built by experienced developers, it takes care of much of the hassle of Web development, so you can focus on writing your app without needing to reinvent the wheel. It’s free and open source.

- **Tailwind CSS**: Tailwind CSS is a highly customizable, low-level CSS framework that gives you all of the building blocks you need to build bespoke designs without any annoying opinionated styles you have to fight to override.

## Pages Of The App

- **Inbox Page**: Contains All the items have been published but only the availabel ones for sale which mean if specific item is sold it won't show. Also contains all categories of these items and tells you how many of items are there in each category. You can click on any item to redirect to the detailed page of this item

- **item/(id) Page**: This is dynamic page which contain all the details of this item (id) so if we change the id that will go to another item. The details are title of the item, price, who sell it and the description of the item. If you are the owner of the item you will see two options, one for edit this item and another option to delete this item. If you don't own this item you will see only one option is to contact with the seller.
  And also there is all related items to this specific item (Categoried)

- **Browse Page**: This page to search for any item in the website and apply filter to reach out your desired item like Categories and you will see all the availabel categories if you press on any of them you will see only the items in this category.

- **Sign Up**: Easy Interface to create new account.

- **Login**: Easy Interface to login to your account.

- **New Item**: You have to login first to go to this page if you haven't it will redirect you to the login page. And if you logged in you will see many fields to fill. First one choose a category to add to, then you have name of the product you wish to sell, The Description of this product, Price and an image of it. Once you filled this out and submit. Wallaaa you published an item, wait for someone to contact you.

- **Dashboard**: This page contain All the items you have published

- **Inbox**: Contain all the messages from other users for specifc item, each item has it's own conversation and it shown as thumbnail to recognize items. You can chat with another users for more details of the item condition and shipping and etc...

## Admin

The app contain one admin superuser can edit the entire models of the app and this can be done with admin page in the app provided by django. you can see there how the entire app works and models relationship.

## What's Next

Some features need to implement Ex:

1. Email verfication
2. Change Password Option
3. Reset Password
4. Admin Dashboard

## Contributing

We welcome contributions from the community. If you would like to contribute, please follow these steps:

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

Before submitting a pull request, please ensure that your code adheres to the existing style.

## Thanks for

All stuff worked to make this course availabel and I want to thank personally Mr David J Malan for all this great fun lectures ♥.

## License

@eldoc

Abdelrahman Samir Selim
